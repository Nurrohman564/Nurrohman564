package com.example.simpleactivity_taufik;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import java.text.BreakIterator;

public class MainActivity extends AppCompatActivity {
    private EditText tahunInput;
    private TextView outputText;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tahunInput = findViewById(R.id.input_name);
        outputText = findViewById(R.id.text_output);
    }
    public void handleSubmit(View view) {
//        String name = nameInput.getText().toString();
//        outputText.setText("Hello" + name);
        int tahun = Integer.parseInt(tahunInput.getText().toString());
        if (tahun >= 1946 && tahun <=1964) {
            outputText.setText("Generasi Baby Boomer" + tahun);
        }else if (tahun >= 1965 && tahun <=1980) {
            outputText.setText("Generasi X" + tahun);
        }else if (tahun >= 1981 && tahun <=1994) {
            outputText.setText("Generasi Y/Milenial" + tahun);
        }else if (tahun >= 1995 && tahun <=2010) {
            outputText.setText("Generasi Z" + tahun);
        }else if(tahun >= 2011 && tahun <=2025) {
            outputText.setText("Generasi Alpha" + tahun);
        }else{
            outputText.setText("Out Of Range" + tahun);
        }
        
    }

}